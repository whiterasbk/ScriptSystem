package whiter.script.activity;
import whiter.script.base.BaseActivity;
import android.os.Bundle;
import whiter.script.R;

public class RunAvtivity extends BaseActivity
{
    @Override
    public void onCreateTest(Bundle savedInstanceState)
    {
        super.onCreateTest(savedInstanceState);
        setContentView(R.layout.run);
    }
}
