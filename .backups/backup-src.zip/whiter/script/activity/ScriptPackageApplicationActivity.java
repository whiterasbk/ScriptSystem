package whiter.script.activity;
import whiter.script.base.BaseActivity;
import android.os.Bundle;

public class ScriptPackageApplicationActivity extends BaseActivity
{

    @Override
    public void onCreateTest(Bundle savedInstanceState)
    {
        // TODO: Implement this method
        super.onCreateTest(savedInstanceState);
    }
}
