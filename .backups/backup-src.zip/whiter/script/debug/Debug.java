package whiter.script.debug;


public class Debug extends Log
{
    
}
