package whiter.script.base;
import android.app.Service;
import whiter.script.test.TestService;

public class BaseService extends TestService
{
    @Override
    public void onCreateTest()
    {
        // TODO: Implement this method
        super.onCreateTest();
    }
}
