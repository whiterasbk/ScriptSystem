package whiter.script.base;
import whiter.script.test.TestContentProvider;

public class BaseContenrProvider extends TestContentProvider
{
}
