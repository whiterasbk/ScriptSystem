package whiter.script.base;
import whiter.script.test.TestBroadcastReceiver;

public class BaseBroadcastReceiver extends TestBroadcastReceiver
{
}
