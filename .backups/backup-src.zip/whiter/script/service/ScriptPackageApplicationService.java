package whiter.script.service;
import whiter.script.base.BaseService;

public class ScriptPackageApplicationService extends BaseService
{
}
