package whiter.script.contentprovider;
import whiter.script.base.BaseContenrProvider;

public class ScriptPackageApplicationContentProvider extends BaseContenrProvider
{
}
