package whiter.script.broadcast;
import whiter.script.base.BaseBroadcastReceiver;

public class ScriptPackageBroadcastReceiver extends BaseBroadcastReceiver
{
}
